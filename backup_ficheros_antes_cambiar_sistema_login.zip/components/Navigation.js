import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { NavigationContainer } from "@react-navigation/native"
import { createStackNavigator } from "@react-navigation/stack"

const Stack = createStackNavigator()

import Home from '../screens/Home'
import Login from '../screens/Login'
import Registro from '../screens/Registro'
import Welcome from '../screens/Welcome'
import DrawNavigation from './DrawNavigation'

export default function Navigation() {
  return (
    <NavigationContainer>
    <Stack.Navigator>
    <Stack.Screen
        name="Welcome"
        component={Welcome}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Login"
        component={Login}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Home"
        component={Home}
        options={{
          headerShown: false,
        }}
      />
       <Stack.Screen
        name="Registro"
        component={Registro}
        options={{
          headerShown: false,
        }}
      />
       <Stack.Screen
        name="DrawNavigation"
        component={DrawNavigation}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  </NavigationContainer>
  )
}