import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Informes() {
  return (
    <View>
      <Text>Informes</Text>
    </View>
  )
}

const styles = StyleSheet.create({})