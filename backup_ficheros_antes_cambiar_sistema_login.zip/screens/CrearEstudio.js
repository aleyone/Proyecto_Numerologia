import { StyleSheet, Text, View, Modal } from "react-native";
import { Input, Button } from 'react-native-elements'
import React from "react";
import {useState} from 'react'

import mapeo from '../utils/MapData'

let letters = [];
let mapLetterNumber = {}

export default function CrearEstudio() {

    const [name, setName] = useState('');
    const [lastName1, setlastName1] = useState('');
    const [lastName2, setlastName2] = useState('');
    const [lastName3, setlastName3] = useState('');
    const [lastName4, setlastName4] = useState('');
    const [day, setDay] = useState('');
    const [month, setMonth] = useState('');
    const [year, setYear] = useState('');

    const mapeoDatos = () => {
        letters = ((name.split()) + (lastName1.split()) + (lastName2.split()) + (lastName3.split()) + (lastName4.split())).toLowerCase();
        ;

        const response = mapeo(letters);
        console.log("Hacemos un console de las letras por un return");
        console.log(response);
        console.log("Ahora vamos a pasarle response a Castillo para que muestre la casa uno");
        
    }
  return (
    <View style= {styles.container}>      
      <Input
        placeholder="Nombre"
        inputStyle={styles.input}
      />
      <Input
        placeholder="Apellido 1"
        inputStyle={styles.input}
      />
      <Input
        placeholder="Apellido 2"
        inputStyle={styles.input}
      />
      <Input
        placeholder="Apellido 3"
        inputStyle={styles.input}
      />
      <Input
        placeholder="Apellido 4"
        inputStyle={styles.input}
      />
      <Input
        placeholder="Día de nacimiento"
        inputStyle={styles.inputDate}
      />
      <Input
        placeholder="Mes de nacimiento"
        inputStyle={styles.inputDate}
      />
      <Input
        placeholder="Año de nacimiento"
        inputStyle={styles.inputDate}
      />
      <Button title="Guardar" buttonStyle={styles.boton} onPress={()=>{mapeoDatos()}}/>
      
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        marginHorizontal: 20,
        marginVertical: 20,
    },
    input: {
        width: "70%",
        height: 10,
    },
    inputDate: {
        width: 150,
        height: 10,
    },
    boton: {
        width: "90%",
        alignSelf: 'center',
        marginTop: 15,
        borderRadius: 10,
        backgroundColor: '#191B4D',
    }
});
