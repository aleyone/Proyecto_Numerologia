import { StyleSheet, Text, View, Modal } from "react-native";
import React from "react";
import { useState } from "react";
import { Icon } from "react-native-elements";

import CrearEstudio from "./CrearEstudio";
import { TouchableOpacity } from "react-native-gesture-handler";
import { cerrarSesion } from "../utils/firebaseActions";

export default function Espacio() {
  const [view, setView] = useState(false);
  return (
    <View>
      <Text onPress={cerrarSesion()}>Espacio</Text>
      <Icon
        type="material-community"
        name="plus"
        reverse
        color="#191B4D"
        containerStyle={styles.icon}
        onPress={() => setView(true)}
      />
      <Text style={styles.text}>Crear Estudio</Text>

      <Modal animationType="slide" transparent visible={view}>
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(1,1,1,0.5",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          
          <View
            style={{
              height: "80%",
              width: "90%",
              backgroundColor: "#FFF",
            }}
          >
            <CrearEstudio />
            <View
              style={{
                height: 45,
                width: "100%",
                
                alignItems: "center",
              }}
            >
              <TouchableOpacity onPress={() => setView(false)}>
                <Icon
                  type="material-community"
                  name="plus"
                  reverse
                  color="#191B4D"
                  containerStyle={styles.icon2}
                  
                />
              </TouchableOpacity>
              
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  icon: {
    position: "absolute",
    bottom: -700,
    right: 10,
    shadowColor: "black",
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.5,
  },
  icon2: {
    position: "absolute",
    bottom: -100,
    right: 10,
    shadowColor: "black",
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.5,
    tintColor: '#000'
  },
  text: {
    position: "absolute",
    bottom: -677,
    right: 80,
    shadowColor: "black",
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.5,
    color: "#191B4D",
  },
});
