import { StyleSheet, Text, View } from "react-native"
import React from "react"
import { useEffect, useState } from "react"
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { initializeApp } from "firebase/app"
import { firebaseConfig } from "../firebase-config"
import { Input, Button } from "react-native-elements"

export default function Login(props) {
  const [email1, setEmail] = useState("");
  const [password1, setPassword] = useState("")
  const app = initializeApp(firebaseConfig)
  const auth = getAuth(app)

  const handleSignIn = () => {
    signInWithEmailAndPassword(auth, email1, password1)
      .then((userCredential) => {
        console.log("Nos logamos")
        const user = userCredential.user
        console.log(user)
        props.navigation.navigate("DrawNavigation")
      })
      .catch((error) => {
        console.log(error)
      });
  };

  return (
    <View>
      <Input
        placeholder="Introduce tu correo"
        inputStyle={styles.input}
        onChangeText={(text) => setEmail(text)}
      />
      <Input
        placeholder="Introduce contraseña"
        inputStyle={styles.input}
        onChangeText={(text) => setPassword(text)}
        secureTextEntry={true}
      />
      <Button title="Accede" buttonStyle={styles.boton} onPress={handleSignIn}/>
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    width: "70%",
    height: 15,
  },
  boton: {
    width: "90%",
    alignSelf: 'center',
    marginTop: 15,
    borderRadius: 10,
    backgroundColor: '#191B4D',
  }
});
