import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { Button } from "react-native-elements";
import DrawNavigation from "../components/DrawNavigation";

export default function Home() {
  return (
    <View style={styles.container}>
      <Text>Home</Text>
      <DrawNavigation />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: "10%",
    marginTop: 100,
    padding: 5,
  },
});
