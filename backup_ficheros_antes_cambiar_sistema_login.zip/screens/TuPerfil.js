import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function TuPerfil() {
  return (
    <View>
      <Text>TuPerfil</Text>
    </View>
  )
}

const styles = StyleSheet.create({})