const mapeo = (letters) => {
    var contadorLetras={};
    var cuentaUno=1, cuentaDos=1, cuentaTres=1, cuentaCuatro=1, cuentaCinco=1, cuentaSeis=1, cuentaSiete=1, cuentaOcho=1, cuentaNueve=1;
    var hasUno=false, hasDos=false, hasTres=false, hasCuatro=false, hasCinco=false, hasSeis=false, hasSiete=false, hasOcho=false, hasNueve=false;
    console.log("he entrado en mapeo");
    console.log("Estas son las letras que recibo: "+letters);
    var letra = letters.split('');
    console.log("Estas son las letras para hacer el map: "+letra);
    
    const resultado = letra.map(function(letras) {

        if (letras == "a" || letras == "j" || letras == "s") {            
            contadorLetras['uno'] = cuentaUno++;
            hasUno=true;
        } else if (letras == "b" || letras == "k" || letras == "t") {
            contadorLetras['dos'] = cuentaDos++;
            hasDos=true;
        } else if (letras == "c" || letras == "l" || letras == "u") {
            contadorLetras['tres'] = cuentaTres++;
            hasTres=true;
        } else if (letras == "d" || letras == "m" || letras == "v") {
            contadorLetras['cuatro'] = cuentaCuatro++;
            hasCuatro=true;
        } else if (letras == "e" || letras == "n" || letras == "w" || letras == "ñ") {
            contadorLetras['cinco'] = cuentaCinco++;
            hasCinco=true;
        } else if (letras == "f" || letras == "o" || letras == "x") {
            contadorLetras['seis'] = cuentaSeis++;
            hasSeis=true;
        } else if (letras == "g" || letras == "p" || letras == "y") {
            contadorLetras['siete'] = cuentaSiete++;
            hasSiete=true;
        } else if (letras == "h" || letras == "q" || letras == "z") {
            contadorLetras['ocho'] = cuentaOcho++;
            hasOcho=true;
        } else if (letras == "i" || letras == "r") {
            contadorLetras['nueve'] = cuentaNueve++;
            hasNueve=true;
        }
        
        return resultado;

    });

    setTimeout (function rellenar(){
        console.log("estoy dentro del rellenar");
        if (hasUno==false) contadorLetras['uno'] = 0;
        if (hasDos==false) contadorLetras['dos'] = 0;
        if (hasTres==false) contadorLetras['tres'] = 0;
        if (hasCuatro==false) contadorLetras['cuatro'] = 0;
        if (hasCinco==false) contadorLetras['cinco'] = 0;
        if (hasSeis==false) contadorLetras['seis'] = 0;
        if (hasSiete==false) contadorLetras['siete'] = 0;
        if (hasOcho==false) contadorLetras['ocho'] = 0;
        if (hasNueve==false) contadorLetras['nueve'] = 0;
    }, 5000);
        
    return contadorLetras;
}

export default mapeo;