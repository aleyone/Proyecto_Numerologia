import { firebaseConfig } from "../firebase-config"
import { getAuth } from "firebase/auth"
import 'firebase/firestore'

const app = initializeApp(firebaseConfig)
const auth = getAuth(app)
const db = app.firestore(firebaseApp)

export const getUsuarioActivo = () => {
    return app.auth().currentUser()
}

export const cerrarSesion = () => {
    return app.auth().signOut()
}